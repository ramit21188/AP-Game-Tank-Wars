
import java.util.*;

public interface buttons {

}
class weapon_select implements buttons{
    public void wps(Tank e){
        Scanner sc=new Scanner(System.in);
        System.out.println("1. nuke");
        System.out.println("2. rockets");
        System.out.println("3. bigshot");
        System.out.println("4. wormhole");
        System.out.println("5. meteor");
        int x2=sc.nextInt();
        if(x2==1){
            e.setw1(new nuke());

        }
        if(x2==2){
            e.setw1(new rockets());


        }
        if(x2==3){
            e.setw1(new bigshots());

        }
        if(x2==4){
            e.setw1(new wormhole());

        }
        if(x2==5){
            e.setw1(new meteor());

        }

    }
}
class fire implements buttons{
    public void fire(Tank e){
        Scanner sc=new Scanner(System.in);
        int f=sc.nextInt();//from 0 to 100;
        e.setPower(f);}
}
class angleset implements buttons{
    Scanner sc=new Scanner(System.in);

    public void changeangle(Tank e){
        int c=sc.nextInt();
        e.setDegree(c);
    }
}
