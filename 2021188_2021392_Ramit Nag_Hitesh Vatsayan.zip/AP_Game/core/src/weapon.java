interface tankshifter{
    public void tankshift(Tank e);
}



abstract class weapon implements tankshifter {
    public abstract void change_heath(Tank e);

}
class nuke extends weapon{
    private final int dest=10;
    private final int shift=5;
    @Override
    public void tankshift(Tank e) {
        e.setX_pos(e.getX_pos()+shift);

    }

    @Override
    public void change_heath(Tank e) {
        e.setHeath(e.getHeath()-dest);

    }
}
class bigshots extends weapon{
    private final int dest=3;
    private final int shift=3;
    @Override
    public void tankshift(Tank e) {
        e.setX_pos(e.getX_pos()+shift);

    }

    @Override
    public void change_heath(Tank e) {
        e.setHeath(e.getHeath()-dest);

    }
}
class rockets extends weapon{
    private final int dest=2;
    private final int shift=2;
    @Override
    public void tankshift(Tank e) {
        e.setX_pos(e.getX_pos()+shift);

    }
    public void change_heath(Tank e) {
        e.setHeath(e.getHeath()-dest);

    }
}
class meteor extends weapon{
    private final int dest=5;
    private final int shift=5;
    @Override
    public void tankshift(Tank e) {
        e.setX_pos(e.getX_pos()+shift);

    }
    public void change_heath(Tank e) {
        e.setHeath(e.getHeath()-dest);

    }
}
class wormhole extends weapon{
    private final int dest=7;
    private final int shift=5;
    @Override
    public void tankshift(Tank e) {
        e.setX_pos(e.getX_pos()+shift);

    }
    public void change_heath(Tank e) {
        e.setHeath(e.getHeath()-dest);

    }
}
