public class Tank {
    private int power;
    private int degree;
    private float x_pos;
    private float y_pos;
    private int heath ;
    private weapon w1;

    public void setw1(weapon w1) {
        this.w1 = w1;
    }

    public void setPower(int power) {
        this.power = power;
    }

    public Tank(int power, int degree, float x_pos, float y_pos, int heath) {
        this.power = power;
        this.degree = degree;
        this.x_pos = x_pos;
        this.y_pos = y_pos;
        this.heath = heath;
    }

    public void setDegree(int degree) {
        this.degree = degree;
    }

    public void setX_pos(float x_pos) {
        this.x_pos = x_pos;
    }

    public void setHeath(int heath) {
        this.heath = heath;
    }

    public void setY_pos(float y_pos) {
        this.y_pos = y_pos;
    }

    public int getDegree() {
        return this.degree;
    }

    public int getPower() {
        return this.power;
    }

    public float getX_pos() {
        return x_pos;
    }

    public float getY_pos() {
        return y_pos;
    }

    public int getHeath() {
        return heath;
    }
}
class abrams extends Tank{

    public abrams(int power, int degree, float x_pos, float y_pos, int heath) {
        super(power, degree, x_pos, y_pos, heath);
    }
}
class frost extends Tank{

    public frost(int power, int degree, float x_pos, float y_pos, int heath) {
        super(power, degree, x_pos, y_pos, heath);
    }
}
class burito extends Tank{
    public burito(int power, int degree, float x_pos, float y_pos, int heath) {
        super(power, degree, x_pos, y_pos, heath);
    }
}
