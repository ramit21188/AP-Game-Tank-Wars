public class main {
    public static void main(String [] args){
        player p1=new player();
        p1.setName("Player 1");
//        p1.setTankname("Tank 1");
        p1.chooseTank();
        player p2=new player();
        p2.setName("Player 2");
        p2.chooseTank();
//        p2.setTankname("Tank 2");

    }
}
