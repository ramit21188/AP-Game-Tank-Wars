package com.mygdx.game.States;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.mygdx.game.MyGdxGame;
import com.mygdx.game.States.State;

public class pauseState extends State {
    private Texture bg;
    private Texture resume;
    private Texture exit;
    private Texture save;
    protected pauseState(com.mygdx.game.States.GameStateManager gsm) {
        super(gsm);
        bg=new Texture("walpaper3.jpg");
        resume=new Texture("Resume.png");
        save=new Texture("save.png");
        exit=new Texture("Close.png");
    }

    @Override
    protected void handleInput() {
        int x3=MyGdxGame.WIDTH/2- exit.getWidth()/2;

        if (Gdx.input.getX() < x3 + exit.getWidth() && Gdx.input.getX() > x3 &&  MyGdxGame.HEIGHT-Gdx.input.getY() < exit.getHeight()+0 && MyGdxGame.HEIGHT-Gdx.input.getY() >0) {
            if (Gdx.input.justTouched()) {
                MyGdxGame.exit();
            }
        }


    }

    @Override
    public void update(float dt) {
//        handleInput();

    }

    @Override
    public void render(SpriteBatch sb) {
        sb.begin();
        sb.draw(bg,0,0, MyGdxGame.WIDTH,MyGdxGame.HEIGHT);
        sb.draw(exit,(MyGdxGame.WIDTH/2)-(exit.getWidth()/6),0,MyGdxGame.WIDTH/4,MyGdxGame.HEIGHT/8);
        sb.draw(resume,(MyGdxGame.WIDTH/2)-(exit.getWidth()/6),(MyGdxGame.HEIGHT/4),MyGdxGame.WIDTH/4,MyGdxGame.HEIGHT/8);
        sb.draw(save,(MyGdxGame.WIDTH/2)-(exit.getWidth()/6),(MyGdxGame.HEIGHT/8),MyGdxGame.WIDTH/4,MyGdxGame.HEIGHT/8);
        sb.end();
    }

    @Override
    public void dispose() {

    }
}
