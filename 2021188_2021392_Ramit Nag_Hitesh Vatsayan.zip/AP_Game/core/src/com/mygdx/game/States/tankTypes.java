package com.mygdx.game.States;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.Texture;
import com.mygdx.game.MyGdxGame;
//import com.mygdx.game.MyGdxGame;

public class tankTypes extends State {
    private Texture txt;
    private Texture bg;
    private Texture tank1;
    private Texture tank2;
    private Texture tank3;



    protected tankTypes(GameStateManager gsm) {
        super(gsm);
        txt=new Texture("chooseTank.png");
        bg= new Texture("warBackground.png");
        tank1=new Texture("tank1.jpg");
        tank2=new Texture("tank2.jpg");
        tank3=new Texture("tank3.jpg");
    }

    @Override
    protected void handleInput() {
        if(Gdx.input.justTouched()){
            gsm.set(new gamePlay(gsm));
            dispose();
        }

    }

    @Override
    public void update(float dt) {
        handleInput();

    }

    @Override
    public void render(SpriteBatch sb) {
        sb.begin();
        sb.draw(bg,0,0,MyGdxGame.WIDTH,MyGdxGame.HEIGHT);
        sb.draw(txt,(MyGdxGame.WIDTH/2)-(txt.getWidth()/2)+50,(MyGdxGame.HEIGHT/2)+50,850,118);
        sb.draw(tank1,20,5,MyGdxGame.WIDTH/4,MyGdxGame.HEIGHT/4);
        sb.draw(tank2,(MyGdxGame.WIDTH/4)+80,5,MyGdxGame.WIDTH/4,MyGdxGame.HEIGHT/4);
        sb.draw(tank3,(MyGdxGame.WIDTH/4)+350,5,MyGdxGame.WIDTH/4,MyGdxGame.HEIGHT/4);
        sb.end();
    }

    @Override
    public void dispose() {

    }

}
