package com.mygdx.game.States;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.mygdx.game.MyGdxGame;

public class menuScreen extends State {
    private Texture play;
    private Texture resume;
    private Texture exit;
    private Texture bg;

    protected menuScreen(GameStateManager gsm) {
        super(gsm);
        play=new Texture("playnow.png");
        resume=new Texture("Resume.png");
        exit=new Texture("Close.png");
        bg= new Texture("walpaper3.jpg");
    }

    @Override
    protected void handleInput() {
        int x = MyGdxGame.WIDTH / 2 - play.getWidth() / 2;
        if (Gdx.input.getX() < x + play.getWidth() && Gdx.input.getX() > x &&  MyGdxGame.HEIGHT-Gdx.input.getY() < play.getHeight()+(2*MyGdxGame.HEIGHT/8)+8 &&MyGdxGame.HEIGHT-Gdx.input.getY() > (2*MyGdxGame.HEIGHT/8)+8) {
            if (Gdx.input.justTouched()) {
                gsm.set(new tankTypes(gsm));
                dispose();
            }
        }
        int x1 = MyGdxGame.WIDTH / 2 - resume.getWidth() / 2;
        if (Gdx.input.getX() < x1 + resume.getWidth() && Gdx.input.getX() > x1 &&  MyGdxGame.HEIGHT-Gdx.input.getY() < resume.getHeight()+(MyGdxGame.HEIGHT/8)+4 && MyGdxGame.HEIGHT-Gdx.input.getY() > (MyGdxGame.HEIGHT/8)+4) {
            if (Gdx.input.justTouched()) {
                gsm.set(new gamePlay(gsm));
                dispose();
            }

            int x2=MyGdxGame.WIDTH/2- exit.getWidth()/2;

            if (Gdx.input.getX() < x2 + exit.getWidth() && Gdx.input.getX() > x2 &&  MyGdxGame.HEIGHT-Gdx.input.getY() < exit.getHeight()+0 && MyGdxGame.HEIGHT-Gdx.input.getY() >0) {
                if (Gdx.input.justTouched()) {
                    MyGdxGame.exit();

                    dispose();
                }
            }    }}






    @Override
    public void update(float dt) {
        handleInput();
    }

    @Override
    public void render(SpriteBatch sb) {
        sb.begin();

        sb.draw(bg,0,0, MyGdxGame.WIDTH,MyGdxGame.HEIGHT);
        sb.draw(exit,(MyGdxGame.WIDTH/2)-(exit.getWidth()/6),0,MyGdxGame.WIDTH/4,MyGdxGame.HEIGHT/8);
        sb.draw(resume,(MyGdxGame.WIDTH/2)-(exit.getWidth()/6),(MyGdxGame.HEIGHT/8)+4,MyGdxGame.WIDTH/4,MyGdxGame.HEIGHT/8);
        sb.draw(play,(MyGdxGame.WIDTH/2)-(exit.getWidth()/6),(2*MyGdxGame.HEIGHT/8)+8,MyGdxGame.WIDTH/4,MyGdxGame.HEIGHT/8);
        sb.end();

    }

    @Override
    public void dispose() {
//        firstScreen.dispose();
    }}

