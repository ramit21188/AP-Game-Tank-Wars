package com.mygdx.game.States;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.mygdx.game.MyGdxGame;

public class Homepage extends State {
    private Texture bg;
    private Sprite sprite;

    @Override
    public void dispose() {
        bg.dispose();
        playbtn.dispose();
    }

    private Texture playbtn;

    public Homepage(GameStateManager gsm) {
        super(gsm);
        bg=new Texture("walpaper.jpg");
        playbtn=new Texture("playButton.png");
    }

    @Override
    public void handleInput() {
        int x = MyGdxGame.WIDTH / 2 - playbtn.getWidth() / 2;
        if (Gdx.input.getX() < x + playbtn.getWidth() && Gdx.input.getX() > x && MyGdxGame.HEIGHT- Gdx.input.getY() < playbtn.getHeight() && MyGdxGame.HEIGHT-Gdx.input.getY() > 0) {
            if (Gdx.input.justTouched()) {
                gsm.set(new menuScreen(gsm));
                dispose();
            }
        }
    }
    @Override
    public void update(float dt) {
        handleInput();
    }

    @Override
    public void render(SpriteBatch sb) {
        sb.begin();
        sb.draw(bg,0,0, MyGdxGame.WIDTH,MyGdxGame.HEIGHT);
        sb.draw(playbtn,(MyGdxGame.WIDTH/2)-(playbtn.getWidth()/2),0);
        sb.end();
    }
}
