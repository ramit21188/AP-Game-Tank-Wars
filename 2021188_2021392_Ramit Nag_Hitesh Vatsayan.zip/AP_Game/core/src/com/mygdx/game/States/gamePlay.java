package com.mygdx.game.States;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.mygdx.game.MyGdxGame;

public class gamePlay extends State{
    private Texture screen1;
    private Texture pause;
    private Texture tank1;
    private Texture tank2;
    float x,y;
    protected gamePlay(GameStateManager gsm) {
        super(gsm);
        screen1=new Texture("ground.jpg");
        pause=new Texture("pause.png");
        tank1=new Texture("TANK.png");
        tank2=new Texture("TANKr.png");
    }

    @Override
    protected void handleInput() {
        if(Gdx.input.justTouched()){
            gsm.set(new pauseState(gsm));
            dispose();
        }
    }

    @Override
    public void update(float dt) {
        handleInput();

    }

    @Override
    public void render(SpriteBatch sb) {
        sb.begin();
        sb.draw(screen1,0,0, MyGdxGame.WIDTH,MyGdxGame.HEIGHT);
        sb.draw(pause,620,380,MyGdxGame.WIDTH/4,MyGdxGame.HEIGHT/10);
        if (Gdx.input.isKeyPressed(Input.Keys.RIGHT)){
            x=x+1;
        }
        if (Gdx.input.isKeyPressed(Input.Keys.LEFT)){
            x=x-1;
        }
        sb.draw(tank2,MyGdxGame.WIDTH/2,10);
        sb.draw(tank1,x,10);
        sb.end();


    }

    @Override
    public void dispose() {

    }
}