package com.mygdx.game.States;

import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public class Menu extends State {
    public Menu(GameStateManager gsm) {
        super(gsm);
    }

    @Override
    public void handleInput() {

    }

    @Override
    public void update(float dt) {

    }

    @Override
    public void render(SpriteBatch sb) {

    }

    @Override
    public void dispose() {

    }
}
