import java.lang.Math.*;
import java.util.ArrayList;

public class pathprojectile {

    private final int ret=10;
    public void path_const(Tank e){
        int powerc=e.getPower();
        int degreec=e.getDegree();
        float cos= (float) Math.cos(degreec);
        float sin=(float) Math.sin(degreec);



        float time=(float)(2*powerc*cos)/ret;
        ArrayList<Float>x_co=new ArrayList<>();
        ArrayList<Float>y_co=new ArrayList<>();
        for(double i=0;i<=time;i=  (i+0.25)){
            x_co.add((float) i*powerc*cos);
             y_co.add((float) (degreec*sin*i+(0.5)*ret*i*i));

        }




    }

}
