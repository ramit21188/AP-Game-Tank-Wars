import java.util.*;
public  class player{
    Scanner sc= new Scanner(System.in);
    private String name;


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }




    public void chooseTank(){
        System.out.println("1. abrams");
        System.out.println("2. frost");
        System.out.println("3. burito");
        int x= sc.nextInt();
        if (x==1){
             abrams a1=new abrams(0,0,0,0,100);

        }
        if (x==2){
            frost f1=new frost(0,0,0,0,100);

        }
        if (x==3){
            burito b1=new burito(0,0,0,0,100);

        }

    }

}
